# ComangliaComs
Max Performance config for most decent PCs

The primary goal of this config was to build off of the previous work done by Chris and I along with the spectacular updates done by Mastercoms. In order to off the best performance for Systems that have relatively Good/New hardware. This config is also aimed more at players who play on servers that use Competitive League Configs.

System Requirements

64-bit OS (I'd imagine 32bit OS's would still work but I have not tested it)

This is primarily designed and tested on Windows, but I have included settings for MacOS and Linux as well.

CPU: Quad-Core or better CPU 
(Single/Dual/Tripe core CPUs will not work well with this CFG)

GPU: A Dedicated GPU capable of DX10 or better 
The Premise of this Config is that you're CPU bound and very few performance settings were chosen with a weak and or intergrated GPU in mind. That said this should still be an improvement over default TF2 settings for all systems that have a good enough CPU.

RAM: Can't give a definite number but if you have near the recommended RAM requirements that your OS recommends you're probably fine. The minimum requirement for Windows 10 64bit is 2GB typically recommended is double the minimum so if you have 4GB of RAM or more you're good to go.
